Installation
------------
Download the map coloring package, unzip it, and place all the files in the
unzipped folder in the JUMP_HOME/lib/ext folder.


Release Notes
=============

Release 0.1
-------------

Initial release of map coloring plugin for OpenJump.
