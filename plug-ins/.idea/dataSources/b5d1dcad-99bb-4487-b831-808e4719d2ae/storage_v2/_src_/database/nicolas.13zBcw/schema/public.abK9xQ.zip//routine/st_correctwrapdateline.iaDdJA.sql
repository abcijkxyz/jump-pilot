create function st_correctwrapdateline(geom_in geometry)
  returns geometry
immutable
language plpgsql
as $$
DECLARE
    multi_line_geom GEOMETRY;
    line_geom       GEOMETRY;
    lastpoint       GEOMETRY;
    lastx           FLOAT;
    pp       INTEGER;
    nn       INTEGER;
    add360 boolean := false;
    lon float;
    geoms geometry[] := '{}';
    geom_out geometry;
    text_var1 text := '';
    text_var2 text := '';
    text_var3 text := '';

BEGIN

    geom_in := ST_MakeValid(geom_in);

    SELECT INTO multi_line_geom ST_Boundary(geom_in);
    -- Loop through multi polygons
    FOR pp IN 1 .. ST_NumGeometries(multi_line_geom) LOOP
        SELECT INTO line_geom ST_GeometryN(multi_line_geom, pp);
        -- reset values
        lastx := ST_X(ST_PointN(line_geom, 1));
        add360 = false;

        FOR nn IN 2 .. ST_NPoints(line_geom) LOOP
            lon = ST_X(ST_PointN(line_geom, nn));
            IF lon - lastx >= 180 THEN
                lon = lon - 360;
                add360 = true;
            ELSEIF lon - lastx <= -180 THEN
                lon = lon + 360;
                add360 = true;
            END IF;
            lastx = lon;
            line_geom := ST_SetPoint(line_geom, nn-1, st_makePoint(lon, ST_Y(ST_PointN(line_geom, nn))));
        END LOOP;

        -- Force first point to be same as last point
        lastpoint := ST_PointN(line_geom, ST_NPoints(line_geom));
        line_geom := ST_SetPoint(line_geom, 0, lastpoint);

        IF add360 THEN
            FOR nn IN 1 .. ST_NPoints(line_geom) LOOP
            line_geom := ST_SetPoint(line_geom, nn-1, st_makePoint(ST_X(ST_PointN(line_geom, nn)) + 360, ST_Y(ST_PointN(line_geom, nn))));
            END LOOP;
        END IF;

        -- set the modified linestring into its collection
        geoms := geoms || line_geom;

    END LOOP;

    geom_out := ST_MakePolygon(geoms[1], geoms[2:array_length(geoms, 1)]);

    --RETURN ST_MakeValid(geom_out);
    RETURN geom_out;
    
    -- If any of above failed, revert to use original polygon
    -- This prevents ingestion error, but may potentially lead to incorrect spatial query.
    EXCEPTION  WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS text_var1 = MESSAGE_TEXT,
                                text_var2 = PG_EXCEPTION_DETAIL,
                                text_var3 = PG_EXCEPTION_HINT;
        raise WARNING 'ST_correctWrapDateLine: exception occured: Msg: %, detail: %, hint: %', text_var1, text_var1, text_var3;
        RETURN geom_in;

END;
$$;

alter function st_correctwrapdateline(geometry)
  owner to nicolas;

