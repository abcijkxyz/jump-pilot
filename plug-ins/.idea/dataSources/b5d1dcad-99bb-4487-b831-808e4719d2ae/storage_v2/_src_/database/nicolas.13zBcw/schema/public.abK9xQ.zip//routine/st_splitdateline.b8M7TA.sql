create function st_splitdateline(geom_in geometry)
  returns geometry
immutable
language plpgsql
as $$
DECLARE
    geom_out   geometry;
    blade      geometry := ST_SetSrid(ST_MakeLine(ST_MakePoint(180, -90), ST_MakePoint(180, 90)), 4326);
    pole_blade geometry := st_geomFromText('POLYGON((-360 -89.9, -360 89.9, 360 89.9, 360 -89.9, -360 -89.9))', 4326);
    text_var1 text := '';
    text_var2 text := '';
    text_var3 text := '';
BEGIN

    -- 2018: polygons are cut if too close to pole:
    geom_in := ST_intersection(st_correctWrapDateLine(geom_in), pole_blade);

    -- Delta longitude is greater than 180 then return splitted geometry
    IF (ST_XMin(geom_in) < -90 AND ST_XMax(geom_in) > 90) OR ST_XMax(geom_in) > 180 OR ST_XMax(geom_in) < -180 THEN

        -- Add 360 to all negative longitudes
        WITH tmp0 AS (
            SELECT geom_in AS geom
        ), tmp AS (
            SELECT st_dumppoints(geom) AS dmp
            FROM tmp0
        ), tmp1 AS (
            SELECT
                (dmp).path,
                CASE WHEN st_X((dmp).geom) < 0
                THEN st_setSRID(st_MakePoint(st_X((dmp).geom) + 360, st_Y((dmp).geom)), 4326)
                ELSE (dmp).geom END AS geom
            FROM tmp
            ORDER BY (dmp).path [2]
        ), tmp2 AS (
            SELECT st_dump(st_split(st_makePolygon(st_makeline(geom)), blade)) AS d
            FROM tmp1
        )
        SELECT ST_Union(
            (
                CASE WHEN ST_Xmax((d).geom) > 180
                THEN ST_Translate((d).geom, -360, 0, 0)
                ELSE (d).geom END
            )
        )
        INTO geom_out
        FROM tmp2;

    -- Delta longitude < 180 degrees then return untouched input geometry
    ELSE
        RETURN geom_in;
    END IF;

    RETURN geom_out;

    -- If any of above failed, revert to use original polygon
    -- This prevents ingestion error, but may potentially lead to incorrect spatial query.
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS text_var1 = MESSAGE_TEXT,
                                text_var2 = PG_EXCEPTION_DETAIL,
                                text_var3 = PG_EXCEPTION_HINT;
        raise WARNING 'ST_correctWrapDateLine: exception occured: Msg: %, detail: %, hint: %', text_var1, text_var1, text_var3;
        RETURN geom_in;

END
$$;

alter function st_splitdateline(geometry)
  owner to nicolas;

