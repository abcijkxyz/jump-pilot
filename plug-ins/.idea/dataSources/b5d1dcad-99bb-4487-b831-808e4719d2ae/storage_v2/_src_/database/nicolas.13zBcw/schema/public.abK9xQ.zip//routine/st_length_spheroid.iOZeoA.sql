create function st_length_spheroid(geometry, spheroid)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT public._postgis_deprecate('ST_Length_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT public.ST_LengthSpheroid($1,$2);
$$;

alter function st_length_spheroid(geometry, spheroid)
  owner to nicolas;

