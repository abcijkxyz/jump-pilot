create function st_distance_sphere(geom1 geometry, geom2 geometry)
  returns double precision
immutable
strict
parallel safe
cost 300
language sql
as $$
SELECT public._postgis_deprecate('ST_Distance_Sphere', 'ST_DistanceSphere', '2.2.0');
    SELECT public.ST_DistanceSphere($1,$2);
$$;

alter function st_distance_sphere(geometry, geometry)
  owner to nicolas;

