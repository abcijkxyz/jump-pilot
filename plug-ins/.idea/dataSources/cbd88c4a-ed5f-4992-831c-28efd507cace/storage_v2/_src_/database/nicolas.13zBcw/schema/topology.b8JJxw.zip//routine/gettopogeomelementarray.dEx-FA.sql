create function gettopogeomelementarray(tg topogeometry)
  returns topoelementarray
stable
strict
language plpgsql
as $$
DECLARE
  toponame varchar;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  RETURN topology.GetTopoGeomElementArray(toponame, tg.layer_id, tg.id);
END;
$$;

comment on function gettopogeomelementarray(topogeometry)
is 'args: tg - Returns a topoelementarray (an array of topoelements) containing the topological elements and type of the given TopoGeometry (primitive elements)';

alter function gettopogeomelementarray(topogeometry)
  owner to nicolas;

