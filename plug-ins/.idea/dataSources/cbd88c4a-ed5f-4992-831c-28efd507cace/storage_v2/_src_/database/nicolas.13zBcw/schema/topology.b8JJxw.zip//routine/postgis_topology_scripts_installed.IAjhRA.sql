create function postgis_topology_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.3.3dev'::text || ' r' || 15331::text AS version
$$;

alter function postgis_topology_scripts_installed()
  owner to nicolas;

