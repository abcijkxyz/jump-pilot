package com.cadplan.jump;

/**
 * User: geoff
 * Date: 19/06/2007
 * Time: 19:05:08
 * Copyright 2005 Geoffrey G Roy.
 */
public class IText
{
    //public static I18NPlug plug;
    public  I18NPlug plug;

    public IText(I18NPlug plug)
    {
        this.plug = plug;

    }
}
