create function addnode(atopology character varying, apoint geometry)
  returns integer
language sql
as $$
SELECT topology.AddNode($1, $2, false, false);
$$;

alter function addnode(varchar, geometry)
  owner to nicolas;

