create function st_approxquantile(rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision, quantile double precision)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT ( public._ST_quantile($1, $2, $3, $4, ARRAY[$5]::double precision[])).value
$$;

alter function st_approxquantile(raster, integer, boolean, double precision, double precision)
  owner to nicolas;

