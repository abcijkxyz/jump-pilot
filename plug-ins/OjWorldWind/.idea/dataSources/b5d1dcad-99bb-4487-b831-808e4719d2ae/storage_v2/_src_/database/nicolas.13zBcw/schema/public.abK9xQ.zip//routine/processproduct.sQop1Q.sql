create function processproduct(geom geometry) returns geometry[]
    immutable
    language plpgsql
as
$$
DECLARE
    v_geom geometry;
    v_shifted_geom geometry;
    v_geom_idx geometry;
    v_geom_display geometry;
BEGIN
    if st_ispolygonccw(geom) then
        raise notice 'geom is CCW => small covered area';

        -- crosses date line ? if so, wrap around 180
        if st_intersects(geom, 'LINESTRING(180 89, 180 0, 180 -89)'::geometry) then
            raise notice 'geom crosses dateline';
            v_geom_display = st_wrapx(v_shifted_geom, 180, -360);
        else
            raise notice 'geom DOES NOT cross dateline';
            v_geom_display = geom;
        end if;

        -- shifts longitude and compare areas
        v_shifted_geom := st_shiftlongitude(geom);
        if st_area(v_shifted_geom) < st_area(geom) then
            -- shifted geom is the smaller: cut on the dateline
            -- geom to index is the shifted geom
            -- geom to display is the shifted geom, wraped on 180
            raise notice 'shifted geom is smaller';
            v_geom_idx = st_wrapx(v_shifted_geom, 180, -360);
        else
            -- input geom is the smallest, must shift if dateline crossed
            raise notice 'geom is smaller';
            v_geom_idx = geom;
        end if;


        return array[v_geom_idx, v_geom_display];

    else
        raise notice 'geom is CW => BIG covered area. TODO...';
        -- cut by 1 degree grid to process parts
    end if;

    -- returns null geoms in other cases
    return array[v_geom_idx, v_geom_display];
end;

$$;

alter function processproduct(geometry) owner to nicolas;

