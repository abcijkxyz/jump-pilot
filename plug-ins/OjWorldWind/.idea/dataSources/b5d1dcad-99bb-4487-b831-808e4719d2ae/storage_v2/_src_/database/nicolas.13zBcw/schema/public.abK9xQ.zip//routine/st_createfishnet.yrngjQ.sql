create function st_createfishnet(nrow integer, ncol integer, xsize double precision, ysize double precision, x0 double precision DEFAULT 0, y0 double precision DEFAULT 0, OUT "row" integer, OUT col integer, OUT geom geometry) returns SETOF record
    immutable
    strict
    language sql
as
$$
SELECT
  i + 1                                        AS row,
  j + 1                                        AS col,
  ST_Translate(cell, j * $3 + $5, i * $4 + $6) AS geom
FROM generate_series(0, $1 - 1) AS i,
      generate_series(0, $2 - 1) AS j,
  (
    SELECT ('POLYGON((0 0, 0 ' || $4 || ', ' || $3 || ' ' || $4 || ', ' || $3 || ' 0,0 0))') :: geometry AS cell
  ) AS foo;
$$;

alter function st_createfishnet(integer, integer, double precision, double precision, double precision, double precision, out integer, out integer, out geometry) owner to nicolas;

