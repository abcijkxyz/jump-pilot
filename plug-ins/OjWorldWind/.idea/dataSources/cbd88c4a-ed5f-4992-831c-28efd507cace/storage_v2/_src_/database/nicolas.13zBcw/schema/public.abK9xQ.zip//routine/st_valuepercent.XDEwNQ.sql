create function st_valuepercent(rast raster, nband integer, exclude_nodata_value boolean, searchvalue double precision, roundto double precision DEFAULT 0)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT ( public._ST_valuecount($1, $2, $3, ARRAY[$4]::double precision[], $5)).percent
$$;

alter function st_valuepercent(raster, integer, boolean, double precision, double precision)
  owner to nicolas;

