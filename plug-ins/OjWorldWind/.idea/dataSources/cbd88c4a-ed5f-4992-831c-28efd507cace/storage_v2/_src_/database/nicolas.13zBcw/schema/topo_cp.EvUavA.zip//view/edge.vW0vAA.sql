create view edge as
  SELECT edge_data.edge_id,
         edge_data.start_node,
         edge_data.end_node,
         edge_data.next_left_edge,
         edge_data.next_right_edge,
         edge_data.left_face,
         edge_data.right_face,
         edge_data.geom
  FROM topo_cp.edge_data;

comment on view edge
is 'Contains edge topology primitives';

alter table edge
  owner to nicolas;

comment on column edge.edge_id
is 'Unique identifier of the edge';

comment on column edge.start_node
is 'Unique identifier of the node at the start of the edge';

comment on column edge.end_node
is 'Unique identifier of the node at the end of the edge';

comment on column edge.next_left_edge
is 'Unique identifier of the next edge of the face on the left (when looking in the direction from START_NODE to END_NODE), moving counterclockwise around the face boundary';

comment on column edge.next_right_edge
is 'Unique identifier of the next edge of the face on the right (when looking in the direction from START_NODE to END_NODE), moving counterclockwise around the face boundary';

comment on column edge.left_face
is 'Unique identifier of the face on the left side of the edge when looking in the direction from START_NODE to END_NODE';

comment on column edge.right_face
is 'Unique identifier of the face on the right side of the edge when looking in the direction from START_NODE to END_NODE';

comment on column edge.geom
is 'The geometry of the edge';

create rule edge_insert_rule as
  on insert
  to edge
do instead -- no commands
;

