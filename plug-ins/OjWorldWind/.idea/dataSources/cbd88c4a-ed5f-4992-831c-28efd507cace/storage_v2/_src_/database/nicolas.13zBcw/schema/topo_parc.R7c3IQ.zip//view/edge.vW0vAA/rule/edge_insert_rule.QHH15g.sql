CREATE RULE edge_insert_rule AS
    ON INSERT TO topo_parc.edge DO INSTEAD  INSERT INTO topo_parc.edge_data (edge_id, start_node, end_node, next_left_edge, abs_next_left_edge, next_right_edge, abs_next_right_edge, left_face, right_face, geom)
  VALUES (new.edge_id, new.start_node, new.end_node, new.next_left_edge, abs(new.next_left_edge), new.next_right_edge, abs(new.next_right_edge), new.left_face, new.right_face, new.geom);

