/* 
 * Kosmo - Sistema Abierto de Informaci�n Geogr�fica
 * Kosmo - Open Geographical Information System
 *
 * http://www.saig.es
 * (C) 2007, SAIG S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation;
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For more information, contact:
 * 
 * Sistemas Abiertos de Informaci�n Geogr�fica, S.L.
 * Avnda. Rep�blica Argentina, 28
 * Edificio Domocenter Planta 2� Oficina 7
 * C.P.: 41930 - Bormujos (Sevilla)
 * Espa�a / Spain
 *
 * Tel�fono / Phone Number
 * +34 954 788876
 * 
 * Correo electr�nico / Email
 * info@saig.es
 *
 */
package org.openjump.advancedtools.plugins;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import org.openjump.advancedtools.icon.IconLoader;
import org.openjump.advancedtools.language.I18NPlug;
import org.openjump.advancedtools.utils.WorkbenchUtils;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jump.I18N;
import com.vividsolutions.jump.feature.Feature;
import com.vividsolutions.jump.workbench.JUMPWorkbench;
import com.vividsolutions.jump.workbench.model.Layer;
import com.vividsolutions.jump.workbench.model.Layerable;
import com.vividsolutions.jump.workbench.plugin.AbstractPlugIn;
import com.vividsolutions.jump.workbench.plugin.EnableCheckFactory;
import com.vividsolutions.jump.workbench.plugin.PlugInContext;
import com.vividsolutions.jump.workbench.ui.AbstractSelection;
import com.vividsolutions.jump.workbench.ui.TaskFrame;
import com.vividsolutions.jump.workbench.ui.plugin.ClearSelectionPlugIn;

/**
 * Executes the selection
 * <p>
 * </p>
 * 
 * @author Sergio Ba&ntilde;os Calvo - sbc@saig.es
 * @since Kosmo 1.1
 * @author Giuseppe Aruta
 * @since OpenJUMP 1.10
 */
public class ClearLayerSelectionPlugIn extends AbstractPlugIn {

    /** Flag to indicate that the shift button has been pressed */
    protected boolean wasShiftPressed;

    /** Query geometry */
    protected Geometry fence;

    /** Selection type */
    protected AbstractSelection selection;

    /** Layer list to filter by */
    protected List<Layerable> layersToFilter;

    /** Name of tool */
    public final static String NAME = I18NPlug
            .getI18N("org.openjump.core.ui.plugins.Deselect");
    /** Description */
    public final static String NAME2 = I18NPlug
            .getI18N("org.openjump.core.ui.plugins.Deselect.description");

    EnableCheckFactory checkFactory = new EnableCheckFactory(JUMPWorkbench
            .getInstance().getContext());

    /**
     * @param toolName
     *            Tool name (to show it in the progress dialog)
     * @param shiftPressed
     *            True if the Shift button has been pressed
     * @param fence
     *            Query geometry
     * @param selection
     * @param layersToFilter
     */
    public ClearLayerSelectionPlugIn() {
    }

    public Icon getIcon() {
        return ICON;
    }

    /** Icono asociado a la herramienta */
    public static ImageIcon ICON = IconLoader.icon("deselectEditing.png");

    @Override
    public String getName() {

        String tooltip = "";
        tooltip = "<HTML><BODY>";

        tooltip += "<b>" + NAME + "</b>";
        tooltip += "</BODY></HTML>";
        return tooltip;
    }

    @Override
    public boolean execute(PlugInContext context) throws Exception {
        reportNothingToUndoYet(context);

        if (!(JUMPWorkbench.getInstance().getFrame().getActiveInternalFrame() instanceof TaskFrame)) {
            JUMPWorkbench
                    .getInstance()
                    .getFrame()
                    .warnUser(
                            I18N.get("com.vividsolutions.jump.workbench.plugin.A-Task-Window-must-be-active"));
            return false;

        }
        try {
            new ClearSelectionPlugIn().execute(context);
        } catch (Exception ex) {
            WorkbenchUtils.Logger(this.getClass(), ex);
        }
        return true;

    }

    /**
     * Refresca la seleccion a partir del mapa de elementos seleccionados para
     * cada capa
     * 
     * @param layerToFeaturesInFenceMap
     * @param panel
     * @param monitor
     * @throws Exception
     */
    protected void refreshSelection(
            Map<Layer, Collection<Feature>> layerToFeaturesInFenceMap,
            PlugInContext context) throws Exception {
        Layer layer = context.getSelectedLayer(0);
        boolean originalPanelUpdatesEnabled = context.getLayerViewPanel()
                .getSelectionManager().arePanelUpdatesEnabled();
        context.getLayerViewPanel().getSelectionManager()
                .setPanelUpdatesEnabled(false);
        try {

            Collection<Feature> featuresToSelect = layerToFeaturesInFenceMap
                    .get(layer);

            Collection<Feature> featuresToUnselect = selection
                    .getFeaturesWithSelectedItems(layer);
            selection.unselectItems(layer, featuresToUnselect);

        } finally {
            context.getLayerViewPanel().getSelectionManager()
                    .setPanelUpdatesEnabled(originalPanelUpdatesEnabled);
        }
        context.getLayerViewPanel().getSelectionManager()
                .setPanelUpdatesEnabled(originalPanelUpdatesEnabled);
        context.getLayerViewPanel().getSelectionManager().updatePanel();
    }

}