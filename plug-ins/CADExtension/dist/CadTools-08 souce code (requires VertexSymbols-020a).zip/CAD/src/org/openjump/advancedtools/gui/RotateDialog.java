/* 
 * Kosmo - Sistema Abierto de Informaci�n Geogr�fica
 * Kosmo - Open Geographical Information System
 *
 * http://www.saig.es
 * (C) 2006, SAIG S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation;
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For more information, contact:
 * 
 * Sistemas Abiertos de Informaci�n Geogr�fica, S.L.
 * Avnda. Rep�blica Argentina, 28
 * Edificio Domocenter Planta 2� Oficina 7
 * C.P.: 41930 - Bormujos (Sevilla)
 * Espa�a / Spain
 *
 * Tel�fono / Phone Number
 * +34 954 788876
 * 
 * Correo electr�nico / Email
 * info@saig.es
 *
 */
package org.openjump.advancedtools.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.openjump.advancedtools.language.I18NPlug;

/**
 * <p>
 * </p>
 * 
 * @author
 * @since Kosmo 1.0
 */
public class RotateDialog extends JDialog implements ChangeListener,
        ActionListener {

    /** long serialVersionUID field */
    private static final long serialVersionUID = 1L;

    JRotationPanel rotationPanel = new JRotationPanel(0);
    JSpinner jspinner = new JSpinner();
    JButton cancelar = new JButton(
            I18NPlug.getI18N("org.openjump.core.ui.plugins.Dialog.Cancel"));
    JButton apply = new JButton(
            I18NPlug.getI18N("org.openjump.core.ui.plugins.Dialog.Apply")
                    + " ->");
    float angle = 0;
    public boolean cancelado = true;

    public RotateDialog(JFrame frame) {
        super(frame, I18NPlug
                .getI18N("org.openjump.core.ui.plugins.Dialog.Angle"), true);
        this.setIconImage(org.openjump.advancedtools.icon.IconLoader
                .image("cadTools.png"));

        JPanel jp = new JPanel();
        jp.add(jspinner);
        jp.add(cancelar);
        jp.add(apply);
        apply.addActionListener(this);
        cancelar.addActionListener(this);
        jspinner.setModel(new SpinnerNumberModel(0, 0, 359, 1));
        jspinner.addChangeListener(this);
        rotationPanel.addChangeListener(this);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(rotationPanel, BorderLayout.CENTER);
        getContentPane().add(jp, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(frame);

        this.setVisible(true);
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (e.getSource().equals(jspinner)) {
            angle = (float) ((((Integer) jspinner.getValue()).intValue() * 2 * Math.PI) / 360);
            rotationPanel.setAngle(angle);
        } else {
            angle = rotationPanel.getAngle();
            jspinner.setValue(new Integer((int) (angle * 360 / (2 * Math.PI))));
        }
    }

    public float getAngle() {
        return angle;
    }

    public float getDegreeAngle() {
        return new Integer((int) (angle * 360 / (2 * Math.PI)));
    }

    @Override
    public void actionPerformed(ActionEvent arg0) {
        if (arg0.getSource() == apply) {
            cancelado = false;
        }
        this.dispose();
    }
}
