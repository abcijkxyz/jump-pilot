package org.openjump.advancedtools.block;

import javax.swing.*;

import org.openjump.advancedtools.icon.IconLoader;
import org.openjump.advancedtools.language.I18NPlug;
import org.openjump.advancedtools.utils.WorkbenchUtils;

import com.vividsolutions.jump.I18N;
import com.vividsolutions.jump.workbench.JUMPWorkbench;
import com.vividsolutions.jump.workbench.WorkbenchContext;
import com.vividsolutions.jump.workbench.plugin.AbstractPlugIn;
import com.vividsolutions.jump.workbench.plugin.EnableCheckFactory;
import com.vividsolutions.jump.workbench.plugin.MultiEnableCheck;
import com.vividsolutions.jump.workbench.plugin.PlugInContext;
import com.vividsolutions.jump.workbench.ui.LayerNamePanelProxy;
import com.vividsolutions.jump.workbench.ui.TaskFrame;
import com.vividsolutions.jump.workbench.ui.cursortool.CursorTool;

public class DrawBlockPlugIn extends AbstractPlugIn {
    public static ImageIcon ICON = IconLoader.icon("textblock/block_ins.png");

    public static final String NAME = I18NPlug
            .getI18N("org.openjump.core.ui.plugins.block.DrawblockTool");
    public static final String NAME2 = I18NPlug
            .getI18N("org.openjump.core.ui.plugins.block.DrawblockTool.description");

    BlockPanel blockPanel;

    public DrawBlockPlugIn(BlockPanel blockPanel) {
        super();
        this.blockPanel = blockPanel;
    }

    @Override
    public boolean execute(PlugInContext context) throws Exception {
        reportNothingToUndoYet(context);

        if (!(JUMPWorkbench.getInstance().getFrame().getActiveInternalFrame() instanceof TaskFrame)) {
            JUMPWorkbench
                    .getInstance()
                    .getFrame()
                    .warnUser(
                            I18N.get("com.vividsolutions.jump.workbench.plugin.A-Task-Window-must-be-active"));
            return false;
        } else {
            try {
                CursorTool polyTool = DrawBlockTool
                        .create((LayerNamePanelProxy) context
                                .getActiveInternalFrame(), blockPanel);
                context.getLayerViewPanel().setCurrentCursorTool(polyTool);
            } catch (Exception ex) {
                WorkbenchUtils.Logger(this.getClass(), ex);
            }
            return true;
        }
    }

    @Override
    public String getName() {

        String tooltip = "";
        tooltip = "<HTML><BODY>";
        tooltip += "<DIV style=\"width: 320px; text-justification: justify;\">";
        tooltip += "<b>" + NAME + "</b>" + "<br>";
        tooltip += NAME2 + "<br>";
        tooltip += "</DIV></BODY></HTML>";
        return tooltip;
    }

    public ImageIcon getIcon() {
        return ICON;
    }

    public static MultiEnableCheck createEnableCheck(
            WorkbenchContext workbenchContext) {
        EnableCheckFactory checkFactory = new EnableCheckFactory(
                workbenchContext);

        return new MultiEnableCheck().add(checkFactory
                .createWindowWithSelectionManagerMustBeActiveCheck());
    }
}
